<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Supplier;
use App\SupplierAddress;
use Auth;
use Datatables;

class SupplierController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Create
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/supplier/create');
    }

    /**
     * Save
     *
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
    	// Parameters
    	$input = $request->all();
    	$input['approved_by'] = Auth::user()->name;
    	$input['created_by'] = Auth::user()->name;
    	$input['modified_by'] = Auth::user()->name;
    	$input['approved_Date'] = date("Y-m-d H:i:s");

        // Address Parameters
        $address['address_type'] = $request->address_type;
        $address['address_line_1'] = $request->address_line_1;
        $address['address_line_2'] = $request->address_line_2;
        $address['address_line_3'] = $request->address_line_3;
        $address['city'] = $request->city;
        $address['post_code'] = $request->post_code;
        $address['province_id'] = $request->province_id;
        $address['area_id'] = $request->area_id;
        $address['country_id'] = $request->country_id;
        $address['phone'] = $request->phone;
        $address['fax'] = $request->fax;
        $address['email'] = $request->email;
        $address['created_by'] = Auth::user()->name;
        $address['modified_by'] = Auth::user()->name;

        //
        $supplierId = Supplier::create( $input );

        //
        $address['supplier_id'] = $supplierId->id;
    	SupplierAddress::create( $address );

    	//
    	return redirect( route('supplier_list') )->with('success', 'Supplier created!');
    }

    /**
     * List
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        //
        return view('admin/supplier/list');
    }

    /**
     * Get Data
     *
     * @return \Illuminate\Http\Response
     */
    public function getData(Request $request)
    {
        // Get Supplier
        $records = Supplier::query();
        
        
        return Datatables::of($records)
                ->editColumn('supplier_name', function($record) {

                    return $record->supplier_name;
                })
                ->editColumn('supplier_type', function($record) {

                    if( $record->supplier_type == 1 ){ return "Local"; }
                    if( $record->supplier_type == 2 ){ return "Import"; }
                })
                ->editColumn('approved', function($record) {

                    return $record->approved ? "Approved" : "Not Approved";
                })
                ->editColumn('approved_by', function($record) {

                    return $record->approved_by;
                })
                ->editColumn('created_at', function($record) {

                    return $record->created_at;
                })
                ->editColumn('action', function($record) {

                    return '

                        &nbsp&nbsp

                        <a href="'.route('view_supplier', $record->id).'"">
                            <img class="view-action" src="'.asset("public/admin/images/view.png").'">
                        </a>
                                
                        &nbsp&nbsp&nbsp&nbsp&nbsp

                        <a href="'.route('delete_supplier', $record->id).'" OnClick="return confirm(\' Are you sure to delete it \');"">
                            <img class="delete-action" src="'.asset("public/admin/images/delete.png").'">
                        </a>

                    ';
                })
                ->rawColumns(['id', 'action'])
                
            ->make(true);
    }

    /**
     * Delete
     *
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request, $id)
    {
        //
        Supplier::destroy( $id );

        //
        return redirect( route('supplier_list') )->with('success', 'Supplier deleted!');
    }

    /**
     * View
     *
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request, $id)
    {
        // Parameters
        $data = Supplier::find( $id );
        $address = SupplierAddress::where( 'supplier_id', $id )->first();

        //
        return view('admin/supplier/view')->with( 'data', $data )->with( 'address', $address );
    }

    /**
     * Save
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Parameters
        $input = $request->all();

        $id = $request->id;
        $data['supplier_name'] = $input['supplier_name'];
        $data['supplier_type'] = $input['supplier_type'];
        $data['approved'] = ( isset( $input['approved'] ) ? 1 : 0 );
        $data['approved_by'] = Auth::user()->name;
        $data['created_by'] = Auth::user()->name;
        $data['modified_by'] = Auth::user()->name;

        // Address Parameters
        $address['address_type'] = $request->address_type;
        $address['address_line_1'] = $request->address_line_1;
        $address['address_line_2'] = $request->address_line_2;
        $address['address_line_3'] = $request->address_line_3;
        $address['city'] = $request->city;
        $address['post_code'] = $request->post_code;
        $address['province_id'] = $request->province_id;
        $address['area_id'] = $request->area_id;
        $address['country_id'] = $request->country_id;
        $address['phone'] = $request->phone;
        $address['fax'] = $request->fax;
        $address['email'] = $request->email;
        $address['created_by'] = Auth::user()->name;
        $address['modified_by'] = Auth::user()->name;

        //
        Supplier::where('id', $id)->update( $data );
        SupplierAddress::where('supplier_id', $id)->update( $address );

        //
        return redirect( route('supplier_list') )->with('success', 'Supplier updated!');
    }
    
}
