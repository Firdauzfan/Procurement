<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Rfq;
use App\Rfi;
use App\RfqDetail;
use App\RfiDetail;
use App\Supplier;
use App\SupplierContact;
use Auth;
use Datatables;

class RfqController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Create
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $supplier = Supplier::all();
        $supplierContact = SupplierContact::all();
        $rfi = Rfi::all();

        //
        return view('admin/rfq/create')->with( 'suppliers', $supplier )->with( 'supplierContacts', $supplierContact )->with( 'rfi', $rfi );
    }

    /**
     * Save
     *
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        //echo '<pre>';
        //print_r( $request->all() );
        //die();
    	// Parameters
    	$input = $request->all();
        $data['supplier_id'] = $request->supplier_id;
        $data['rfi_id'] = 0;
        $data['supplier_contact_id'] = $request->supplier_contact_id;

        $data['inquiry_customer'] = $request->inquiry_customer;
        $data['vendor_reference'] = $request->vendor_reference;
        $data['rfq_number'] = $request->rfq_number;
        $data['order_date'] = $request->order_date;

        $data['status'] = 1;
    	$data['created_by'] = Auth::user()->name;
    	$data['modified_by'] = Auth::user()->name;

        //SAVE RFQ
        $rfq = Rfq::create( $data );

        //TRUNCATE DETAIL
        RfqDetail::where('rfq_id', $rfq->id)->truncate();

        //DETAIL
        if( !empty( $request->items ) )
        {
            //ITEMS
            foreach ($request->items as $itemId => $get)
            {
                $rfqDetail['rfi_detail_id'] = null;
                $rfqDetail['sequence_number'] = null;
                $rfqDetail['type_product_id'] = null;
                $rfqDetail['product_id'] = $itemId;
                $rfqDetail['qty_rfq'] = $get["qty"];
                $rfqDetail['um_rfq'] = $get["um"];
                $rfqDetail['status'] = 1;
                $rfqDetail['validation_needed'] = null;
                
                //SAVE DETAIL
                $rfqDetail['rfq_id'] = $rfq->id;
                RfqDetail::create( $rfqDetail );
            }
        }

    	//
    	return redirect( route('rfq_list') )->with('success', 'Request for quotation created');
    }

    /**
     * List
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        //
        return view('admin/rfq/list');
    }

    /**
     * Get Data
     *
     * @return \Illuminate\Http\Response
     */
    public function getData(Request $request)
    {
        // Get Supplier
        $records = Rfq::query();
        
        
        return Datatables::of($records)
                ->editColumn('supplier_id', function($record) {

                    $supplier = Supplier::select('supplier_name')->where( 'id', $record->supplier_id )->first();
                    return $supplier->supplier_name;
                })
                ->editColumn('supplier_contact_id', function($record) {

                    $contact = SupplierContact::select('contact_name')->where( 'id', $record->supplier_contact_id )->first();
                    return $contact->contact_name;
                })
                ->editColumn('status', function($record) {

                    if( $record->status == '1' )
                    {
                        return 'Approved';
                    }
                    else
                    {
                        return 'Pending';
                    }
                })
                ->editColumn('created_at', function($record) {

                    return $record->created_at;
                })
                ->editColumn('action', function($record) {

                    return '

                        &nbsp&nbsp

                        <a href="'.route('view_rfq', $record->id).'"">
                            <img class="view-action" src="'.asset("public/admin/images/view.png").'">
                        </a>
                                
                        &nbsp&nbsp&nbsp&nbsp&nbsp

                        <a href="'.route('delete_rfq', $record->id).'" OnClick="return confirm(\' Are you sure to delete it \');"">
                            <img class="delete-action" src="'.asset("public/admin/images/delete.png").'">
                        </a>

                    ';
                })
                ->rawColumns(['id', 'action'])
                
            ->make(true);
    }

    /**
     * Delete
     *
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request, $id)
    {
        //
        Rfq::destroy( $id );

        //
        return redirect( route('rfq_list') )->with('success', 'Supplier deleted!');
    }

    /**
     * View
     *
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request, $id)
    {
        //
        $supplier = Supplier::all();
        $supplierContact = SupplierContact::all();
        $data = Rfq::find( $id );
        $dataDetail = RfqDetail::where( 'rfq_id', $id )->first();

        //
        return view('admin/rfq/view')->with( 'data', $data )->with( 'suppliers', $supplier )->with( 'supplierContacts', $supplierContact )->with( 'dataDetail', $dataDetail );
    }

    /**
     * Save
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Parameters
        $input = $request->all();

        $id = $request->id;
        $input = $request->all();
        $data['supplier_id'] = $request->supplier_id;
        $data['supplier_contact_id'] = $request->supplier_contact_id;
        $data['status'] = $request->rfq_status;
        $data['created_by'] = Auth::user()->name;
        $data['modified_by'] = Auth::user()->name;

        // Parameters

        $rfqDetail['rfi_detail_id'] = $request->rfi_detail_id;
        $rfqDetail['sequence_number'] = $request->sequence_number;
        $rfqDetail['type_product_id'] = $request->type_product_id;
        $rfqDetail['product_id'] = $request->product_id;
        $rfqDetail['qty_rfq'] = $request->qty_rfq;
        $rfqDetail['um_rfq'] = $request->um_rfq;
        $rfqDetail['status'] = $request->rfq_detail_status;
        $rfqDetail['validation_needed'] = $request->validation_needed;

        //
        Rfq::where('id', $id)->update( $data );
        RfqDetail::where('rfq_id', $id)->update( $rfqDetail );

        //
        return redirect( route('rfq_list') )->with('success', 'RFQ updated!');
    }
    
}
