<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RfiDetail extends Model
{
    protected $table = 'rfi_detail';


    public $timestamps = true;
}
