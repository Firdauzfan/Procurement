	

<?php $__env->startSection('content'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Update RFQ</h3>
			</div>
		</div>
	</div>	
	<form action="<?php echo e(route('update_rfq')); ?>" method="post">
	<div class="tab-content padding40px shadowDiv">
		
			<?php echo csrf_field(); ?>

			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier</label>
							<div class="col-md-7">
								<select name="supplier_id" class="form-control">
									<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<?php if( $supplier->id == $data->supplier_id ): ?>
											<option value="<?php echo e($supplier->id); ?>" selected=""><?php echo e($supplier->supplier_name); ?></option>
										<?php else: ?>
											<option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->supplier_name); ?></option>
										<?php endif; ?>
										
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier Contact</label>
							<div class="col-md-7">
								<select name="supplier_contact_id" class="form-control">
									<?php $__currentLoopData = $supplierContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierContact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<?php if( $supplierContact->id == $data->supplier_contact_id ): ?>
											<option value="<?php echo e($supplierContact->id); ?>" selected="selected"><?php echo e($supplierContact->contact_name); ?></option>
										<?php else: ?>
											<option value="<?php echo e($supplierContact->id); ?>"><?php echo e($supplierContact->contact_name); ?></option>
										<?php endif; ?>
										
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<select name="rfq_status" class="form-control">
									<option <?php echo ( @$data->status == 1 ? "selected=''" : '' ); ?> value="1">Approved</option>
									<option <?php echo ( @$data->status == 2 ? "selected=''" : '' ); ?> value="2">Pending</option>
								</select>
							</div>
						</div>
					</div>

					<input type="hidden" value="<?php echo e($data->id); ?>" name="id">
					
			</div>
		
	</div>

	<!-- RFQ Detail -->

	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Request For Quotation Detail</h3>
			</div>
		</div>
	</div>
	<div class="tab-content padding40px shadowDiv">
		
			<?php echo csrf_field(); ?>

			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Request For Inquiry Id</label>
							<div class="col-md-7">
								<input name="rfi_detail_id" value="<?php echo e(@$dataDetail->rfi_detail_id); ?>" class="form-control m-input" type="number">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Sequence Number</label>
							<div class="col-md-7">
								<input name="sequence_number" value="<?php echo e(@$dataDetail->sequence_number); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Type Product Id</label>
							<div class="col-md-7">
								<select name="type_product_id" class="form-control">
									<option <?php echo ( @$dataDetail->type_product_id == 0 ? "selected=''" : '' ); ?> value="0">Buffer</option>
									<option <?php echo ( @$dataDetail->type_product_id == 1 ? "selected=''" : '' ); ?> value="1">Catalogue</option>
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Product Id</label>
							<div class="col-md-7">
								<input name="product_id" value="<?php echo e(@$dataDetail->product_id); ?>" class="form-control m-input" type="number">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Qty RFQ</label>
							<div class="col-md-7">
								<input name="qty_rfq" value="<?php echo e(@$dataDetail->qty_rfq); ?>" class="form-control m-input" type="text">
							</div>
						</div>

					</div>

					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">UM RFQ</label>
							<div class="col-md-7">
								<input name="um_rfq" value="<?php echo e(@$dataDetail->um_rfq); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<input name="rfq_detail_status" value="<?php echo e(@$dataDetail->status); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Validation Needed</label>
							<div class="col-md-7">
								<select name="validation_needed" class="form-control">
									<option <?php echo ( @$dataDetail->validation_needed == 0 ? "selected=''" : '' ); ?> value="0">Yes</option>
									<option <?php echo ( @$dataDetail->validation_needed == 1 ? "selected=''" : '' ); ?> value="1">No</option>
								</select>
							</div>
						</div>

					</div>

					<div class="m-portlet__foot m-portlet__foot--fit margin50px">
						<div class="m-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Update</button>&nbsp;&nbsp;
									<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								</div>
							</div>
						</div>
					</div>

					
			</div>
		
	</div>

	<!-- /RFQ Detail -->

	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>