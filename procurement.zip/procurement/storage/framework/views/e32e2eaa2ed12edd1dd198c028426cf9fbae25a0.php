<?php $__env->startSection('content'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Item(Product) Buffer Price List</h3>
        <a href="<?php echo e(route('create_buffer_price')); ?>" class="btn btn-accent m-btn m-btn--air m-btn--custom">Create</a>
			</div>
		</div>
		<div class="sub-heading">
			<?php if(session('success')): ?>
			    <?php echo e(session('success')); ?>

			<?php endif; ?>
		</div>
	</div>

	<div class="tab-content padding40px">
		<table class="table table-bordered" id="table">
           <thead>
              <tr>
                 <th>Sequence Number</th>
                 <th>Qty Item</th>
                 <th>Unit Cost</th>
                 <th>Sell Price</th>
                 <th>Price Date</th>
                 <th>Price Valid Until</th>
                 <th>Action</th>
              </tr>
           </thead>
        </table>
	</div>
</div>
<link href="https://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" href='<?php echo e(asset("css/jquery-ui.min.css")); ?>' />

<script type="text/javascript" src='<?php echo e(asset("js/jquery-ui.min.js")); ?>'></script>
<script type="text/javascript" src='<?php echo e(asset("js/jquery.dataTables.min.js")); ?>'></script>

<script type="text/javascript" src='<?php echo e(asset("js/dataTables.bootstrap4.min.js")); ?>'></script>

<script type="text/javascript">

$(function() {
               $('#table').DataTable({
               processing: true,
               serverSide: true,
               ajax: "<?php echo e(route('buffer_price_data')); ?>",
               columns: [
                        { data: 'sequence_number', name: 'sequence_number' },
                        { data: 'qty_item', name: 'qty_item' },
                        { data: 'unit_cost', name: 'unit_cost' },
                        { data: 'sell_price', name: 'sell_price' },
                        { data: 'price_date', name: 'price_date' },
                        { data: 'price_valid_until', name: 'price_valid_until' },
                        { data: 'action', name: 'action', searchable: 'false' },
                      
                     ]
            });
         });

 </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>