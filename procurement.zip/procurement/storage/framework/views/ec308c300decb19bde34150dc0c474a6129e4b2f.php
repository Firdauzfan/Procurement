<?php $__env->startSection('content'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Detail Purchase Order Detail</h3>
			</div>
		</div>
	</div>	
	<form action="<?php echo e(route('save_purchase_order_detail')); ?>" method="post" enctype="multipart/form-data">
	<div class="tab-content padding40px shadowDiv">
		
			<?php echo csrf_field(); ?>

			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">
						<input type="hidden" value="<?php echo e($purchaseOrderId); ?>" name="purchase_order_id">
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Purchase Request ID</label>
							<div class="col-md-7">
								<input type="text" value="<?php echo e(isset($data->pr_detail_id) ? $data->pr_detail_id : ''); ?>" name="pr_detail_id" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Sepuence Number</label>
							<div class="col-md-7">
								<input type="text" value="<?php echo e(isset($data->sequence_number) ? $data->sequence_number : ''); ?>" name="sequence_number" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Product ID</label>
							<div class="col-md-7">
								<select name="product_id" class="form-control">
									<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if( @$data->product_id == $get->id ): ?>
											<option value="<?php echo e($get->id); ?>" selected=""><?php echo e($get->part_name); ?></option>
										<?php else: ?>
											<option value="<?php echo e($get->id); ?>"><?php echo e($get->part_name); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Qty POS</label>
							<div class="col-md-7">
								<input required="" name="qty_pos" value="<?php echo e(isset($data->qty_pos) ? $data->qty_pos : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">UM POS</label>
							<div class="col-md-7">
								<input required="" name="um_pos" value="<?php echo e(isset($data->um_pos) ? $data->um_pos : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Balance Qty</label>
							<div class="col-md-7">
								<input type="text" name="balance_qty" value="<?php echo e(isset($data->balance_qty) ? $data->balance_qty : ''); ?>" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Curr</label>
							<div class="col-md-7">
								<input type="text" name="curr" value="<?php echo e(isset($data->curr) ? $data->curr : ''); ?>" class="form-control">
							</div>
						</div>
						
					</div>

					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Unit Price</label>
							<div class="col-md-7">
								<input required="" name="unit_price" value="<?php echo e(isset($data->unit_price) ? $data->unit_price : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Have External Reference?</label>
							<div class="col-md-7">
								<div id="file1" class="btn-group radio-style">
								    <label class="btn-">
								        <input type="radio" <?php echo ( @$data->have_external_reference == 1 ? "checked=''" : '' ); ?> value=1 class="have_external_reference" name="have_external_reference" /> Yes
								    </label>
								    <label class="btn-">
								        <input type="radio" value=0 <?php echo ( @$data->have_external_reference == 0 ? "checked=''" : '' ); ?> class="have_external_reference" name="have_external_reference" /> No
								    </label>
								</div>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Target Data Original</label>
							<div class="col-md-7">
								<input required="" name="target_date_original" value="<?php echo e(isset($data->target_date_original) ? $data->target_date_original : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Target Data New</label>
							<div class="col-md-7">
								<input required="" name="target_date_new" value="<?php echo e(isset($data->target_date_new) ? $data->target_date_new : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Last Arrival Date</label>
							<div class="col-md-7">
								<input required="" name="last_arrival_date" value="<?php echo e(isset($data->last_arrival_date) ? $data->last_arrival_date : ''); ?>" class="date form-control m-input file-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<input required="" name="status" value="<?php echo e(isset($data->status) ? $data->status : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>


					</div>

					<div class="m-portlet__foot m-portlet__foot--fit margin50px">
						<div class="m-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Update</button>&nbsp;&nbsp;
									<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								</div>
							</div>
						</div>
					</div>

					
			</div>
		
	</div>
	</form>

	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Detail Purchase Order Detail Target Datelog</h3>
			</div>
		</div>
	</div>	
	<form action="<?php echo e(route('save_purchase_order_detail')); ?>" method="post" enctype="multipart/form-data">
	<div class="tab-content padding40px shadowDiv">
		
			<?php echo csrf_field(); ?>

			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">
						<input type="hidden" value="<?php echo e($purchaseOrderId); ?>" name="purchase_order_id">
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Purchase Request ID</label>
							<div class="col-md-7">
								<input type="text" value="<?php echo e(isset($data->pr_detail_id) ? $data->pr_detail_id : ''); ?>" name="pr_detail_id" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Sepuence Number</label>
							<div class="col-md-7">
								<input type="text" value="<?php echo e(isset($data->sequence_number) ? $data->sequence_number : ''); ?>" name="sequence_number" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Product ID</label>
							<div class="col-md-7">
								<select name="product_id" class="form-control">
									<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if( @$data->product_id == $get->id ): ?>
											<option value="<?php echo e($get->id); ?>" selected=""><?php echo e($get->part_name); ?></option>
										<?php else: ?>
											<option value="<?php echo e($get->id); ?>"><?php echo e($get->part_name); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Qty POS</label>
							<div class="col-md-7">
								<input required="" name="qty_pos" value="<?php echo e(isset($data->qty_pos) ? $data->qty_pos : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">UM POS</label>
							<div class="col-md-7">
								<input required="" name="um_pos" value="<?php echo e(isset($data->um_pos) ? $data->um_pos : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Balance Qty</label>
							<div class="col-md-7">
								<input type="text" name="balance_qty" value="<?php echo e(isset($data->balance_qty) ? $data->balance_qty : ''); ?>" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Curr</label>
							<div class="col-md-7">
								<input type="text" name="curr" value="<?php echo e(isset($data->curr) ? $data->curr : ''); ?>" class="form-control">
							</div>
						</div>
						
					</div>

					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Unit Price</label>
							<div class="col-md-7">
								<input required="" name="unit_price" value="<?php echo e(isset($data->unit_price) ? $data->unit_price : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Have External Reference?</label>
							<div class="col-md-7">
								<div id="file1" class="btn-group radio-style">
								    <label class="btn-">
								        <input type="radio" <?php echo ( @$data->have_external_reference == 1 ? "checked=''" : '' ); ?> value=1 class="have_external_reference" name="have_external_reference" /> Yes
								    </label>
								    <label class="btn-">
								        <input type="radio" value=0 <?php echo ( @$data->have_external_reference == 0 ? "checked=''" : '' ); ?> class="have_external_reference" name="have_external_reference" /> No
								    </label>
								</div>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Target Data Original</label>
							<div class="col-md-7">
								<input required="" name="target_date_original" value="<?php echo e(isset($data->target_date_original) ? $data->target_date_original : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Target Data New</label>
							<div class="col-md-7">
								<input required="" name="target_date_new" value="<?php echo e(isset($data->target_date_new) ? $data->target_date_new : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Last Arrival Date</label>
							<div class="col-md-7">
								<input required="" name="last_arrival_date" value="<?php echo e(isset($data->last_arrival_date) ? $data->last_arrival_date : ''); ?>" class="date form-control m-input file-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<input required="" name="status" value="<?php echo e(isset($data->status) ? $data->status : ''); ?>" class="form-control m-input" type="text">
							</div>
						</div>


					</div>

					<div class="m-portlet__foot m-portlet__foot--fit margin50px">
						<div class="m-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Update</button>&nbsp;&nbsp;
									<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								</div>
							</div>
						</div>
					</div>

					
			</div>
		
	</div>
	</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>