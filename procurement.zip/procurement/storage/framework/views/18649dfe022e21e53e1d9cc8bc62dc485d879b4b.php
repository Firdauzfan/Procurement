	

<?php $__env->startSection('content'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Create Item(Product) Price</h3>
			</div>
		</div>
	</div>	
	<form action="<?php echo e(route('update_price')); ?>" method="post" enctype="multipart/form-data">
	<div class="tab-content padding40px shadowDiv">
		
			<?php echo csrf_field(); ?>

			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Product</label>
							<div class="col-md-7">
								<select name="product_id" class="form-control">
									<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option <?php echo ( $data->product_id == $item->id ? "selected=''" : '' ); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->part_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Sequence Number</label>
							<div class="col-md-7">
								<input name="sequence_number" value="<?php echo e($data->sequence_number); ?>" class="form-control m-input" type="text">
								<input name="id" value="<?php echo e($data->id); ?>" class="form-control m-input" type="hidden">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Qty Item</label>
							<div class="col-md-7">
								<input name="qty_item" value="<?php echo e($data->qty_item); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Unit Cost</label>
							<div class="col-md-7">
								<input name="unit_cost" value="<?php echo e($data->unit_cost); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Sell Price</label>
							<div class="col-md-7">
								<input name="sell_price" value="<?php echo e($data->sell_price); ?>"" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Price Date</label>
							<div class="col-md-7">
								<input name="price_date" value="<?php echo e($data->price_date); ?>"" class="form-control m-input" type="text">
							</div>
						</div>

						

					</div>

					<div class="col-md-6">
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Price Valid Until</label>
							<div class="col-md-7">
								<input name="price_valid_until" value="<?php echo e($data->price_valid_until); ?>" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<input name="status" value="<?php echo e($data->status); ?>" class="form-control m-input" type="text">
							</div>
						</div>
						
					</div>

					<div class="m-portlet__foot m-portlet__foot--fit margin50px">
						<div class="m-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Create</button>&nbsp;&nbsp;
									<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								</div>
							</div>
						</div>
					</div>

					
			</div>
		
	</div>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>