	@extends('layouts.admin')

@section('content')
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Upate Quotation</h3>
			</div>
		</div>
	</div>	
	<form action="{{ route('update_quotation') }}" method="post" enctype="multipart/form-data">
	<div class="tab-content padding40px shadowDiv">
			
			<input required="" name="id" value="{{ $data->id }}" class="form-control m-input" type="hidden">
			{!! csrf_field() !!}
			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Quotation Supplier Number</label>
							<div class="col-md-7">
								<input required="" name="qs_num" value="{{ $data->qs_num }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Quotation Supplier Date</label>
							<div class="col-md-7">
								<input required="" name="qs_date" value="{{ $data->qs_date }}" class="date form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Request For Quote</label>
							<div class="col-md-7">
								<select required="" name="rfq_id" class="form-control">
									@foreach( $rfq as $get )
										@if( $data->rfq_id == $get->id )
											<option value="{{ $get->id }}" selected="">{{ $get->id }}</option>
										@else
											<option value="{{ $get->id }}">{{ $get->id }}</option>
										@endif
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier</label>
							<div class="col-md-7">
								<select required="" name="supplier_id" class="form-control">
									@foreach( $suppliers as $get )
										@if( $data->supplier_id == $get->id )
											<option value="{{ $get->id }}" selected="">{{ $get->supplier_name }}</option>
										@else
											<option value="{{ $get->id }}">{{ $get->supplier_name }}</option>
										@endif
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier Contact</label>
							<div class="col-md-7">
								<select required="" name="supplier_contact_id" class="form-control">
									@foreach( $supplierContacts as $get )
										@if( $data->supplier_contact_id == $get->id )
											<option value="{{ $get->id }}" selected="">{{ $get->contact_name }}</option>
										@else
											<option value="{{ $get->id }}">{{ $get->contact_name }}</option>
										@endif
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Shipment Term</label>
							<div class="col-md-7">
								<input required="" name="shipment_term" value="{{ $data->shipment_term }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Payment Term</label>
							<div class="col-md-7">
								<input required="" name="payment_term" value="{{ $data->payment_term }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Import Via</label>
							<div class="col-md-7">
								<select required="" name="import_via" class="form-control">
									<option <?php echo ( $data->import_via == 0 ? "selected=''" : '' ); ?> value="0">Local</option>
									<option <?php echo ( $data->import_via == 1 ? "selected=''" : '' ); ?> value="1">Air</option>
									<option <?php echo ( $data->import_via == 2 ? "selected=''" : '' ); ?> value="2">Sea</option>
								</select>
							</div>
						</div>

					</div>

					<div class="col-md-6">
						
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Cost Freight</label>
							<div class="col-md-7">
								<select required="" name="cost_freight" class="form-control">
									<option <?php echo ( $data->cost_freight == 0 ? "selected=''" : '' ); ?> value="0">Paid</option>
									<option <?php echo ( $data->cost_freight == 1 ? "selected=''" : '' ); ?> value="1">Not Paid</option>
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Cost Freight Amount</label>
							<div class="col-md-7">
								<input required="" name="cost_freight_amount" value="{{ $data->cost_freight_amount }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Quotation Supplier Rating</label>
							<div class="col-md-7">
								<input required="" name="qs_rating" value="{{ $data->qs_rating }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Remark</label>
							<div class="col-md-7">
								<input required="" name="remark" value="{{ $data->remark }}" class="form-control m-input" type="text">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Attached File</label>
							<div class="col-md-7">
								<input required="" name="attached_file" value="{{ $data->attached_file }}" class="form-control m-input file-input" type="file">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Status</label>
							<div class="col-md-7">
								<input required="" name="status" value="{{ $data->status }}" class="form-control m-input" type="text">
							</div>
						</div>

					</div>

					<div class="m-portlet__foot m-portlet__foot--fit margin50px">
						<div class="m-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Update</button>&nbsp;&nbsp;
									<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								</div>
							</div>
						</div>
					</div>

					
			</div>
		
	</div>
	</form>
</div>

@endsection