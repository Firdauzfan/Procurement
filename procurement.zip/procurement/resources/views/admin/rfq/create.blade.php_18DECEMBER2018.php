	@extends('layouts.admin')

@section('content')
<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<h3 class="m-subheader__title ">Request For Quotation</h3>
			</div>
		</div>
	</div>	
	<form action="{{ route('save_rfq') }}" method="post">
	<div class="tab-content padding40px shadowDiv">
		
			{!! csrf_field() !!}
			<div class="row" id="m_user_profile_tab_1">
					<div class="col-md-6">

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier</label>
							<div class="col-md-7">
								<select required="" onchange="supplierChange(this.value)" name="supplier_id" class="form-control">
									@foreach( $suppliers as $supplier )
										<option value="{{ $supplier->id }}">{{ $supplier->supplier_name }}</option>
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Supplier Contact</label>
							<div class="col-md-7">
								<select required="" name="supplier_contact_id" class="form-control supplier-contact">
									@foreach( $supplierContacts as $supplierContact )
										<option value="{{ $supplierContact->id }}">{{ $supplierContact->contact_name }}</option>
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Inquiry Customer</label>
							<div class="col-md-7">
								<select required="" name="inquiry_customer" class="form-control inquiry-customer">
									@foreach( $rfi as $get )
										<option value="{{ $get->id }}">alex{{ $get->customer_id }}</option>
									@endforeach
								</select>
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Vendor Reference</label>
							<div class="col-md-7">
								<input type="text" name="vendor_reference" class="form-control" id="">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Manufacturer</label>
							<div class="col-md-7">
								<input type="text" placeholder="Type to filter" class="form-control" id="mfr">
							</div>
						</div>

					</div>

					<div class="col-md-6">
						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">RFQ #</label>
							<div class="col-md-7">
								<input type="text" name="rfq_number" class="form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Order Date</label>
							<div class="col-md-7">
								<input type="text" name="order_date" class="date form-control">
							</div>
						</div>

						<div class="form-group m-form__group row">
							<label for="example-text-input" class="col-md-3 col-form-label">Part Name</label>
							<div class="col-md-7">
								<input type="text" placeholder="Type to filter" class="form-control" id="part-name">
							</div>
						</div>

					</div>

					
			</div>
		
	</div>

	<!-- RFQ Detail -->

	<div class="m-subheader ">
		<div class="d-flex align-items-center">
			<div class="mr-auto">
				<!--<h3 class="m-subheader__title ">Request For Quotation Detail</h3>-->
			</div>
		</div>
	</div>


	<div class="tab-content padding40px shadowDiv itemDiv">

			<span class="product-tab">Products</span>

			<div class="row" id="m_user_profile_tab_1">

				<!-- Item Module -->

				<table class="table table-bordered" id="table">
					<thead>
		              <tr>
		                 <th>MFR</th>
		                 <th>Part Name</th>
		                 <th>Part Number</th>
		                 <th>Part Description</th>
		                 <th>Quantity</th>
		                 <th>UM</th>
		              </tr>
		           </thead>
				</table>

				<!-- /Item Module -->
				
				<div class="m-portlet__foot m-portlet__foot--fit margin50px">
					<div class="m-form__actions">
						<div class="row">
							<div class="col-12">
								<button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom">Create</button>&nbsp;&nbsp;
								<button type="reset" class="btn btn-secondary m-btn m-btn--air m-btn--custom">Cancel</button>
								<a href="{{ route('create_item') }}" class="btn btn-secondary m-btn m-btn--air m-btn--custom"><i class="fa fa-plus"></i>&nbsp&nbspAdd Item</a>
							</div>
						</div>
					</div>
				</div>

					
			</div>
		
	</div>

	<!-- /RFQ Detail -->

	</form>
</div>

<link href="https://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" href='{{ asset("public/css/jquery-ui.min.css") }}' />
<style>.dataTables_length{display: none;} .dataTables_filter{display: none;}</style>
<script type="text/javascript" src='{{ asset("public/js/jquery-ui.min.js") }}'></script>
<script type="text/javascript" src='{{ asset("public/js/jquery.dataTables.min.js") }}'></script>

<script type="text/javascript" src='{{ asset("public/js/dataTables.bootstrap4.min.js") }}'></script>

<script type="text/javascript">

$(function() {
       var table = $('#table').DataTable({
       processing: true,
       serverSide: true,
       ajax: "{{ route('item_table') }}",
       columns: [
                { data: 'mfr', name: 'mfr' },
                { data: 'part_name', name: 'part_name' },
                { data: 'part_num', name: 'part_num' },
                { data: 'part_desc', name: 'part_desc' },
                { data: 'qty', name: 'qty' },
                { data: 'um', name: 'um' },
              
             ]
    });

       $('#mfr').on( 'keyup', function () {
		    table
		        .columns( 0 )
		        .search( this.value )
		        .draw();
		} );

       $('#part-name').on( 'keyup', function () {
		    table
		        .columns( 1 )
		        .search( this.value )
		        .draw();
		} );
 });

//
supplierChange( '{{ $suppliers[0]->id }}' );

//
function supplierChange(value)
{
	$.ajax(
	{
	  url: "{{ URL::to('supplier/contact/get') }}/"+value
	})
	.done(function(data)
	{
	  $('.supplier-contact').html('');
	  $('.supplier-contact').html(data);
	});
}
 </script>
@endsection